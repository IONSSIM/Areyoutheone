<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'localwp');

/** MySQL database username */
define('DB_USER', 'wpuser');

/** MySQL database password */
define('DB_PASSWORD', 'billisawesome123');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '6eDh#^+9FC]77BP!v,_88T R,~GD):u,uC2t i4s+=ZC^1VR;BkE8rjsdvcTc.!K');
define('SECURE_AUTH_KEY',  'A~b8*X?O4Qi^zx*C*X$EjMVkR~[Fwg*W?0A*;~GX K&$Kzx_m/7lhG#tg%$RvR{v');
define('LOGGED_IN_KEY',    '9jy_Vpd{N{V1k)(h!apF:U|R>2w<^i,wNyyL}Rbh(7.gfR:-Gj*=y3dnzC/=~ISl');
define('NONCE_KEY',        '&r~ou93)QnluE`&^ul.X4OKke}M oN-h*+{.|%/.mH`<M:^$%|^i9;)tW-C4{gS$');
define('AUTH_SALT',        'sCpJH<|c>FAB>GWEhMUsmcUK9Ba]{kz~[$Fw`FnH;eF!fnT{%vr7Oy{}MA.|2#sh');
define('SECURE_AUTH_SALT', 'hi9[RNE/I]ncV%C^IQC|3i!<U|`i:GBa:NF-uT[p1Y6HmLh<J7t(m9^axmFZ7fO[');
define('LOGGED_IN_SALT',   'Tw~Vg4T=pr}>mGk9~3Q@O2Dke:xk|V K;uvI]S~YuY -$G{R2kU/pD_u@rR)*Fo7');
define('NONCE_SALT',       'I(U`qwd#dka<2Q<jpj?pQe]>z^i?ll1HdEt`R3W5b&L@s[Q4U]N^CO47C r3i0Yx');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'localwp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
