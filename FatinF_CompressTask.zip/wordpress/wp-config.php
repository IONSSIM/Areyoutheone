<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress-test');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'Y*;yRS,Tld0>|57 ?=T)QU$=(bClC;=rTOmp~`pfD}_Ik|dHBLel%!kF{H?Gqd`k');
define('SECURE_AUTH_KEY',  'V=?6Hf<<m6!,Vjh[)A)L<G-1mb_0+j?~V&HiL-/#ln^|G=b>fI&?qi|@U(xXtnHv');
define('LOGGED_IN_KEY',    'xTnnw2)v3k|9f@^g_v},(w.!.6!B&#@($XN6ns`Z^<l0wRPpo,0`p_8,-Ys9NHR(');
define('NONCE_KEY',        '2Qiv6q$%L&JdZEL^vx5.o@&<-YOt=m-Ukdh5$g=J@5`$`Vei|C<L|~8&2{U-J`_#');
define('AUTH_SALT',        'uGQD;?R_HTM[-VMISrr|Xa_7W<PnV{>OilCIgC)as8Ugv@;Dz>fODUS+Da,mSB_^');
define('SECURE_AUTH_SALT', '2(H rWb8DpQ;x9<rfp0d_L}mXeM!%B7iwx]5,T.%%LxvW8mXtmc!ERt;b{xKszV&');
define('LOGGED_IN_SALT',   'ROOn(L@cljR*+ oZ2^R?]q$oe]0I/J3Xm0UQ+7s]0?L41=C)d5SfX i->v;fE:hi');
define('NONCE_SALT',       'tZ/LIOZ#Ki+#%mu1`j{Wi^-w/=+/3F[aM)&Xu@r4Kpx|yTf).yNEP~DM=pp#7tv}');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', true);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
